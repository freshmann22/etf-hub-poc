// ETF 허브 메인화면 PoC — 상태 관리 및 이벤트 연결 (브라우저 전용)
import {
  etfs,
  themes,
  stocks,
  holdings,
  contents,
  marketSummaryByPeriod,
  comparisonSets,
} from './data.js';
import {
  getRankedEtfs,
  getThemeHeatmap,
  getEtfsByTheme,
  getEtfsByStock,
  searchAll,
  getComparison,
  filterContents,
  getMarketSummary,
} from './logic.js';
import {
  renderSearchResults,
  renderMarketSummary,
  renderHeatmap,
  renderRankingList,
  renderStockChips,
  renderStockEtfResults,
  renderThemeCards,
  renderComparisonTable,
  renderCompareEtfSelect,
  renderContentList,
  renderBottomSheet,
} from './render.js';

const REQUIRED_STOCK_NAMES = [
  '삼성전자',
  'SK하이닉스',
  'NAVER',
  '한화에어로스페이스',
  '두산에너빌리티',
  '현대차',
];

const themeById = new Map(themes.map((t) => [t.id, t]));
const stockById = new Map(stocks.map((s) => [s.id, s]));
const etfById = new Map(etfs.map((e) => [e.id, e]));

const chipStocks = REQUIRED_STOCK_NAMES.map((name) => stocks.find((s) => s.name === name)).filter(
  Boolean
);

function buildIssueByEtfId() {
  const map = new Map();
  contents
    .filter((c) => c.type === 'news')
    .forEach((c) => {
      c.relatedEtfIds.forEach((etfId) => {
        if (!map.has(etfId)) map.set(etfId, c.summary);
      });
    });
  return map;
}
const issueByEtfId = buildIssueByEtfId();

const state = {
  heatmapPeriod: '1d',
  rankingTab: 'gainers',
  selectedThemeId: null,
  selectedStockId: chipStocks.length ? chipStocks[0].id : null,
  compareThemeId: comparisonSets[0].themeId,
  compareEtfIds: comparisonSets[0].etfIds.slice(),
  contentFilter: 'news',
  query: '',
  bottomSheetEtfId: null,
  lastFocusedElement: null,
};

// ---------------------------------------------------------------------------
// DOM refs
// ---------------------------------------------------------------------------
const searchInput = document.getElementById('search-input');
const searchResultsEl = document.getElementById('search-results');
const marketSummaryBodyEl = document.getElementById('market-summary-body');
const heatmapGridEl = document.getElementById('heatmap-grid');
const rankingListEl = document.getElementById('ranking-list');
const stockChipsEl = document.getElementById('stock-chips');
const stockEtfResultsEl = document.getElementById('stock-etf-results');
const themeCardsBodyEl = document.getElementById('theme-cards-body');
const compareThemeSelectEl = document.getElementById('compare-theme-select');
const compareEtfSelectEl = document.getElementById('compare-etf-select');
const compareTableEl = document.getElementById('compare-table');
const contentListEl = document.getElementById('content-list');
const bottomSheetEl = document.getElementById('bottom-sheet');
const bottomSheetBackdropEl = document.getElementById('bottom-sheet-backdrop');

const periodTabButtons = Array.from(document.querySelectorAll('.period-tab'));
const rankingTabButtons = Array.from(document.querySelectorAll('.ranking-tab'));
const contentFilterButtons = Array.from(document.querySelectorAll('.content-filter'));

// ---------------------------------------------------------------------------
// Render functions per section
// ---------------------------------------------------------------------------
function renderMarket() {
  const summary = getMarketSummary(marketSummaryByPeriod, '1d');
  renderMarketSummary(marketSummaryBodyEl, summary, themeById);
}

function renderHeatmapSection() {
  const items = getThemeHeatmap(themes, state.heatmapPeriod);
  renderHeatmap(heatmapGridEl, items, (themeId) => {
    state.selectedThemeId = state.selectedThemeId === themeId ? null : themeId;
    renderRankingSection();
  });

  periodTabButtons.forEach((btn) => {
    const isActive = btn.dataset.value === state.heatmapPeriod;
    btn.setAttribute('aria-selected', String(isActive));
    btn.classList.toggle('active', isActive);
  });
}

function renderRankingSection() {
  const base = state.selectedThemeId ? getEtfsByTheme(etfs, state.selectedThemeId) : etfs;
  const ranked = getRankedEtfs(base, state.rankingTab);
  renderRankingList(rankingListEl, ranked, {
    themeById,
    stockById,
    issueByEtfId,
    tab: state.rankingTab,
    onSelectEtf: openBottomSheet,
  });

  rankingTabButtons.forEach((btn) => {
    const isActive = btn.dataset.value === state.rankingTab;
    btn.setAttribute('aria-selected', String(isActive));
    btn.classList.toggle('active', isActive);
  });
}

function renderStockSection() {
  renderStockChips(stockChipsEl, chipStocks, state.selectedStockId, (stockId) => {
    state.selectedStockId = stockId;
    renderStockSection();
  });

  const results = state.selectedStockId
    ? getEtfsByStock(etfs, holdings, state.selectedStockId)
    : [];
  renderStockEtfResults(stockEtfResultsEl, results, { themeById });
}

function renderThemeSection() {
  const topThemes = themes
    .slice()
    .sort((a, b) => b.tradingValue - a.tradingValue)
    .slice(0, 6);
  renderThemeCards(themeCardsBodyEl, topThemes, { etfById, stockById });
}

function renderCompareThemeOptions() {
  compareThemeSelectEl.innerHTML = '';
  comparisonSets.forEach((set) => {
    const theme = themeById.get(set.themeId);
    const option = document.createElement('option');
    option.value = set.themeId;
    option.textContent = theme ? theme.name : set.themeId;
    if (set.themeId === state.compareThemeId) option.selected = true;
    compareThemeSelectEl.appendChild(option);
  });
}

function renderCompareSection() {
  const themeEtfs = getEtfsByTheme(etfs, state.compareThemeId);
  renderCompareEtfSelect(compareEtfSelectEl, themeEtfs, state.compareEtfIds);

  const rows = getComparison(etfs, holdings, stocks, state.compareEtfIds);
  renderComparisonTable(compareTableEl, rows);
}

function renderContentSection() {
  const list = filterContents(contents, state.contentFilter);
  renderContentList(contentListEl, list);

  contentFilterButtons.forEach((btn) => {
    const isActive = btn.dataset.value === state.contentFilter;
    btn.setAttribute('aria-selected', String(isActive));
    btn.classList.toggle('active', isActive);
  });
}

function renderSearchSection() {
  const result = searchAll({ etfs, stocks, themes }, state.query);
  renderSearchResults(searchResultsEl, result, {
    onSelectEtf: (etfId) => openBottomSheet(etfId),
    onSelectStock: (stockId) => {
      state.selectedStockId = stockId;
      renderStockSection();
      document.querySelector('.stock-explore-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    },
    onSelectTheme: (themeId) => {
      state.selectedThemeId = themeId;
      renderRankingSection();
      document.querySelector('.ranking-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    },
  });
}

// ---------------------------------------------------------------------------
// Bottom sheet
// ---------------------------------------------------------------------------
function openBottomSheet(etfId) {
  const etf = etfById.get(etfId);
  if (!etf) return;

  state.bottomSheetEtfId = etfId;
  state.lastFocusedElement = document.activeElement;

  renderBottomSheet(bottomSheetEl, etf, {
    themeById,
    stockById,
    onClose: closeBottomSheet,
  });

  bottomSheetEl.hidden = false;
  bottomSheetBackdropEl.hidden = false;

  const closeBtn = bottomSheetEl.querySelector('[data-testid="bottom-sheet-close"]');
  if (closeBtn) closeBtn.focus();

  document.addEventListener('keydown', onKeydownForSheet);
}

function closeBottomSheet() {
  state.bottomSheetEtfId = null;
  bottomSheetEl.hidden = true;
  bottomSheetBackdropEl.hidden = true;
  bottomSheetEl.innerHTML = '';
  document.removeEventListener('keydown', onKeydownForSheet);

  if (state.lastFocusedElement && typeof state.lastFocusedElement.focus === 'function') {
    state.lastFocusedElement.focus();
  }
}

function onKeydownForSheet(event) {
  if (event.key === 'Escape') {
    closeBottomSheet();
  }
}

bottomSheetBackdropEl.addEventListener('click', closeBottomSheet);

// ---------------------------------------------------------------------------
// Event bindings
// ---------------------------------------------------------------------------
searchInput.addEventListener('input', (event) => {
  state.query = event.target.value;
  renderSearchSection();
});

periodTabButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    state.heatmapPeriod = btn.dataset.value;
    renderHeatmapSection();
  });
});

rankingTabButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    state.rankingTab = btn.dataset.value;
    renderRankingSection();
  });
});

contentFilterButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    state.contentFilter = btn.dataset.value;
    renderContentSection();
  });
});

compareThemeSelectEl.addEventListener('change', (event) => {
  const themeId = event.target.value;
  state.compareThemeId = themeId;
  const matchingSet = comparisonSets.find((s) => s.themeId === themeId);
  state.compareEtfIds = matchingSet
    ? matchingSet.etfIds.slice()
    : getEtfsByTheme(etfs, themeId)
        .slice(0, 3)
        .map((e) => e.id);
  renderCompareSection();
});

compareEtfSelectEl.addEventListener('change', (event) => {
  const selected = Array.from(event.target.selectedOptions).map((opt) => opt.value);
  state.compareEtfIds = selected.length ? selected : state.compareEtfIds;
  renderCompareSection();
});

// ---------------------------------------------------------------------------
// Initial render
// ---------------------------------------------------------------------------
renderSearchSection();
renderMarket();
renderHeatmapSection();
renderRankingSection();
renderStockSection();
renderThemeSection();
renderCompareThemeOptions();
renderCompareSection();
renderContentSection();
