// ETF 허브 메인화면 PoC — DOM 렌더링 함수 (브라우저 전용)
import {
  formatSignedPercent,
  formatKrw,
  formatPrice,
} from './logic.js';

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  Object.entries(attrs).forEach(([key, value]) => {
    if (value === null || value === undefined) return;
    if (key === 'className') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key.startsWith('on') && typeof value === 'function') {
      node.addEventListener(key.slice(2).toLowerCase(), value);
    } else {
      node.setAttribute(key, value);
    }
  });
  (Array.isArray(children) ? children : [children]).forEach((child) => {
    if (child === null || child === undefined) return;
    if (typeof child === 'string') node.appendChild(document.createTextNode(child));
    else node.appendChild(child);
  });
  return node;
}

function signedClass(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'neutral';
  if (value > 0) return 'up';
  if (value < 0) return 'down';
  return 'neutral';
}

function changeSpan(value) {
  return el('span', { className: 'change ' + signedClass(value), text: formatSignedPercent(value) });
}

// ---------------------------------------------------------------------------
// 검색 결과
// ---------------------------------------------------------------------------
export function renderSearchResults(container, result, handlers) {
  container.innerHTML = '';

  if (result.isEmptyQuery) {
    container.appendChild(
      el('p', { className: 'empty-state' }, '검색어를 입력하면 ETF, 종목, 테마 결과를 볼 수 있어요.')
    );
    return;
  }

  const hasAny = result.etfs.length || result.stocks.length || result.themes.length;
  if (!hasAny) {
    container.appendChild(el('p', { className: 'empty-state' }, '조건에 맞는 ETF를 찾지 못했어요.'));
    return;
  }

  if (result.etfs.length) {
    const group = el('div', { className: 'search-group' }, [el('h3', {}, 'ETF')]);
    const list = el('ul', { className: 'search-result-list' });
    result.etfs.forEach((etf) => {
      const item = el('li', {}, [
        el(
          'button',
          {
            type: 'button',
            className: 'search-result-btn',
            onClick: () => handlers.onSelectEtf(etf.id),
          },
          [
            el('span', { className: 'result-name' }, etf.name),
            el('span', { className: 'result-code' }, etf.code),
          ]
        ),
      ]);
      list.appendChild(item);
    });
    group.appendChild(list);
    container.appendChild(group);
  }

  if (result.stocks.length) {
    const group = el('div', { className: 'search-group' }, [el('h3', {}, '종목')]);
    const list = el('ul', { className: 'search-result-list' });
    result.stocks.forEach((stock) => {
      const item = el('li', {}, [
        el(
          'button',
          {
            type: 'button',
            className: 'search-result-btn',
            onClick: () => handlers.onSelectStock(stock.id),
          },
          [
            el('span', { className: 'result-name' }, stock.name),
            el('span', { className: 'result-code' }, stock.code),
          ]
        ),
      ]);
      list.appendChild(item);
    });
    group.appendChild(list);
    container.appendChild(group);
  }

  if (result.themes.length) {
    const group = el('div', { className: 'search-group' }, [el('h3', {}, '테마')]);
    const list = el('ul', { className: 'search-result-list' });
    result.themes.forEach((theme) => {
      const item = el('li', {}, [
        el(
          'button',
          {
            type: 'button',
            className: 'search-result-btn',
            onClick: () => handlers.onSelectTheme(theme.id),
          },
          [el('span', { className: 'result-name' }, theme.name)]
        ),
      ]);
      list.appendChild(item);
    });
    group.appendChild(list);
    container.appendChild(group);
  }
}

// ---------------------------------------------------------------------------
// 오늘의 ETF 시장
// ---------------------------------------------------------------------------
export function renderMarketSummary(container, summary, themeById) {
  container.innerHTML = '';

  const strongTheme = themeById.get(summary.strongestThemeId);
  const weakTheme = themeById.get(summary.weakestThemeId);

  const stats = el('div', { className: 'market-stats' }, [
    statTile('상승', summary.advancers + '개', 'up'),
    statTile('하락', summary.decliners + '개', 'down'),
    statTile('보합', summary.unchanged + '개', 'neutral'),
  ]);

  const trading = el('div', { className: 'market-trading' }, [
    el('span', { className: 'market-trading-label' }, '전체 거래대금'),
    el('span', { className: 'market-trading-value' }, formatKrw(summary.totalTradingValue)),
    changeSpan(summary.tradingValueChangeRate),
    el('span', { className: 'market-trading-note' }, '(전일 대비)'),
  ]);

  const themesRow = el('div', { className: 'market-themes' }, [
    el('div', { className: 'market-theme-card strong' }, [
      el('span', { className: 'label' }, '가장 강한 테마'),
      el('span', { className: 'theme-name' }, strongTheme ? strongTheme.name : '정보 없음'),
    ]),
    el('div', { className: 'market-theme-card weak' }, [
      el('span', { className: 'label' }, '가장 약한 테마'),
      el('span', { className: 'theme-name' }, weakTheme ? weakTheme.name : '정보 없음'),
    ]),
  ]);

  const summaryText = el('p', { className: 'market-summary-text' }, summary.summary);

  container.append(stats, trading, themesRow, summaryText);
}

function statTile(label, value, tone) {
  return el('div', { className: 'stat-tile ' + tone }, [
    el('span', { className: 'stat-value' }, value),
    el('span', { className: 'stat-label' }, label),
  ]);
}

// ---------------------------------------------------------------------------
// 히트맵
// ---------------------------------------------------------------------------
export function renderHeatmap(container, heatmapItems, onSelectTheme) {
  container.innerHTML = '';

  if (!heatmapItems.length) {
    container.appendChild(el('p', { className: 'empty-state' }, '표시할 테마가 없어요.'));
    return;
  }

  const maxTradingValue = Math.max(...heatmapItems.map((t) => t.tradingValue || 0));

  heatmapItems.forEach((item, index) => {
    const isTopTier = index < 2;
    const card = el(
      'button',
      {
        type: 'button',
        className: 'heatmap-card' + (isTopTier ? ' heatmap-card--wide' : '') + ' ' + signedClass(item.returnRate),
        'data-testid': 'heatmap-card',
        onClick: () => onSelectTheme(item.themeId),
      },
      [
        el('span', { className: 'heatmap-theme-name' }, item.name),
        changeSpan(item.returnRate),
        el(
          'span',
          { className: 'heatmap-trading-value' },
          '거래대금 ' + formatKrw(item.tradingValue)
        ),
        el(
          'span',
          { className: 'heatmap-rep-etf' },
          item.representativeEtfIds.length
            ? '대표 ETF ' + item.representativeEtfIds.length + '종목'
            : ''
        ),
      ]
    );
    const relativeSize = maxTradingValue > 0 ? (item.tradingValue || 0) / maxTradingValue : 0;
    card.style.setProperty('--relative-size', relativeSize.toFixed(2));
    container.appendChild(card);
  });
}

// ---------------------------------------------------------------------------
// 지금 많이 움직인 ETF
// ---------------------------------------------------------------------------
export function renderRankingList(container, etfList, ctx) {
  container.innerHTML = '';

  if (!etfList.length) {
    container.appendChild(el('p', { className: 'empty-state' }, '표시할 ETF가 없어요.'));
    return;
  }

  etfList.slice(0, 8).forEach((etf) => {
    container.appendChild(renderEtfCard(etf, ctx));
  });
}

function renderEtfCard(etf, ctx) {
  const theme = ctx.themeById.get(etf.themeId);
  const topStocks = etf.topHoldings
    .slice(0, 3)
    .map((stockId) => ctx.stockById.get(stockId))
    .filter(Boolean);

  const issue = ctx.issueByEtfId ? ctx.issueByEtfId.get(etf.id) : null;

  return el(
    'button',
    {
      type: 'button',
      className: 'etf-card',
      'data-testid': 'etf-card',
      onClick: () => ctx.onSelectEtf(etf.id),
    },
    [
      el('div', { className: 'etf-card-header' }, [
        el('span', { className: 'etf-name' }, etf.name),
        el('span', { className: 'etf-code' }, etf.code),
      ]),
      el('div', { className: 'etf-card-price' }, [
        el('span', { className: 'etf-price' }, formatPrice(etf.currentPrice)),
        changeSpan(etf.changeRate1d),
      ]),
      el('div', { className: 'etf-card-meta' }, [
        el(
          'span',
          {},
          '거래대금 ' +
            formatKrw(etf.tradingValue) +
            (ctx.tab === 'volume' &&
            typeof etf.tradingValueChangeRate === 'number' &&
            Number.isFinite(etf.tradingValueChangeRate)
              ? ' (' + formatSignedPercent(etf.tradingValueChangeRate) + ' 전일 대비)'
              : '')
        ),
        theme ? el('span', { className: 'theme-tag' }, theme.name) : null,
      ]),
      topStocks.length
        ? el(
            'div',
            { className: 'etf-card-holdings' },
            '주요 구성종목 ' + topStocks.map((s) => s.name).join(', ')
          )
        : null,
      issue ? el('p', { className: 'etf-card-issue' }, issue) : null,
    ]
  );
}

// ---------------------------------------------------------------------------
// 관심 종목으로 ETF 찾기
// ---------------------------------------------------------------------------
export function renderStockChips(container, stocks, selectedStockId, onSelect) {
  container.innerHTML = '';
  stocks.forEach((stock) => {
    const isActive = stock.id === selectedStockId;
    container.appendChild(
      el(
        'button',
        {
          type: 'button',
          className: 'stock-chip' + (isActive ? ' active' : ''),
          'data-testid': 'stock-chip',
          'aria-pressed': String(isActive),
          onClick: () => onSelect(stock.id),
        },
        stock.name
      )
    );
  });
}

export function renderStockEtfResults(container, results, ctx = {}) {
  container.innerHTML = '';

  if (!results.length) {
    container.appendChild(
      el('p', { className: 'empty-state' }, '이 종목을 담은 ETF를 찾지 못했어요.')
    );
    return;
  }

  results.forEach(({ etf, weight, rank }) => {
    const theme = ctx.themeById ? ctx.themeById.get(etf.themeId) : null;
    container.appendChild(
      el('div', { className: 'stock-result-card' }, [
        el('div', { className: 'stock-result-header' }, [
          el('span', { className: 'etf-name' }, etf.name),
          el('span', { className: 'weight-badge' }, formatSignedPercent(weight).replace('+', '') ),
        ]),
        el('div', { className: 'stock-result-meta' }, [
          el('span', {}, '편입비중 ' + weight + '%'),
          el('span', {}, '비중 순위 ' + rank + '위'),
          theme ? el('span', { className: 'theme-tag' }, theme.name) : null,
        ]),
        el('div', { className: 'stock-result-meta' }, [
          el('span', {}, '순자산 ' + formatKrw(etf.netAssets)),
          el('span', {}, '거래대금 ' + formatKrw(etf.tradingValue)),
        ]),
      ])
    );
  });
}

// ---------------------------------------------------------------------------
// 오늘 주목할 테마
// ---------------------------------------------------------------------------
export function renderThemeCards(container, themes, ctx) {
  container.innerHTML = '';

  themes.forEach((theme) => {
    const repEtfs = theme.representativeEtfIds
      .map((id) => ctx.etfById.get(id))
      .filter(Boolean);
    const repStocks = theme.representativeStockIds
      .map((id) => ctx.stockById.get(id))
      .filter(Boolean);

    container.appendChild(
      el('div', { className: 'theme-card' }, [
        el('div', { className: 'theme-card-header' }, [
          el('span', { className: 'theme-name' }, theme.name),
          changeSpan(theme.return1d),
        ]),
        repEtfs.length
          ? el('p', { className: 'theme-rep-etf' }, '대표 ETF ' + repEtfs.map((e) => e.name).join(', '))
          : null,
        repStocks.length
          ? el('p', { className: 'theme-rep-stock' }, '주요 종목 ' + repStocks.map((s) => s.name).join(', '))
          : null,
        el('p', { className: 'theme-issue' }, theme.issueSummary),
        el(
          'p',
          { className: 'theme-trading-change' },
          '거래대금 변화 ' + formatSignedPercent(theme.tradingValueChangeRate)
        ),
      ])
    );
  });
}

// ---------------------------------------------------------------------------
// 같은 테마 ETF 비교
// ---------------------------------------------------------------------------
export function renderComparisonTable(container, comparisonRows) {
  container.innerHTML = '';

  if (!comparisonRows.length) {
    container.appendChild(el('p', { className: 'empty-state' }, '비교할 ETF 데이터가 없어요.'));
    return;
  }

  const table = el('table', { className: 'compare-table' });
  const thead = el('thead', {}, [
    el('tr', {}, [
      el('th', {}, '구분'),
      ...comparisonRows.map((row) => el('th', {}, row.name)),
    ]),
  ]);

  const rowsMeta = [
    { label: '주요 구성종목', get: (r) => (r.topHoldingNames.length ? r.topHoldingNames.join(', ') : '정보 없음') },
    { label: '상위 2종목 집중도', get: (r) => (r.top2Concentration === null ? '정보 없음' : r.top2Concentration.toFixed(1) + '%') },
    { label: '순자산', get: (r) => formatKrw(r.netAssets) },
    { label: '거래대금', get: (r) => formatKrw(r.tradingValue) },
    { label: '총보수', get: (r) => (typeof r.totalFee === 'number' ? r.totalFee.toFixed(2) + '%' : '정보 없음') },
    { label: '1개월 수익률', get: (r) => formatSignedPercent(r.return1m) },
  ];

  const tbody = el(
    'tbody',
    {},
    rowsMeta.map((meta) =>
      el('tr', {}, [el('th', {}, meta.label), ...comparisonRows.map((row) => el('td', {}, meta.get(row)))])
    )
  );

  table.append(thead, tbody);
  container.appendChild(table);

  container.appendChild(
    el(
      'p',
      { className: 'compare-note' },
      '상품 간 차이는 구조적 차이일 뿐 우열을 의미하지 않아요.'
    )
  );
}

export function renderCompareEtfSelect(selectEl, availableEtfs, selectedIds) {
  selectEl.innerHTML = '';
  availableEtfs.forEach((etf) => {
    const option = el('option', { value: etf.id }, etf.name);
    if (selectedIds.includes(etf.id)) option.setAttribute('selected', 'selected');
    selectEl.appendChild(option);
  });
}

// ---------------------------------------------------------------------------
// 뉴스·공시·리서치
// ---------------------------------------------------------------------------
const TYPE_LABEL = { news: '뉴스', disclosure: '공시', research: '리서치' };

export function renderContentList(container, contentList) {
  container.innerHTML = '';

  if (!contentList.length) {
    container.appendChild(el('p', { className: 'empty-state' }, '해당 유형의 콘텐츠가 없어요.'));
    return;
  }

  contentList.forEach((content) => {
    const date = new Date(content.publishedAt);
    const dateText = Number.isNaN(date.getTime()) ? '정보 없음' : date.toLocaleDateString('ko-KR');

    container.appendChild(
      el('div', { className: 'content-card' }, [
        el('div', { className: 'content-card-header' }, [
          el('span', { className: 'content-type-badge' }, TYPE_LABEL[content.type] || content.type),
          el('span', { className: 'content-date' }, dateText),
        ]),
        el('h3', { className: 'content-title' }, content.title),
        el('p', { className: 'content-summary' }, content.summary),
      ])
    );
  });
}

// ---------------------------------------------------------------------------
// 바텀시트
// ---------------------------------------------------------------------------
export function renderBottomSheet(container, etf, ctx) {
  container.innerHTML = '';

  if (!etf) return;

  const theme = ctx.themeById.get(etf.themeId);
  const topStocks = etf.topHoldings
    .map((stockId) => ctx.stockById.get(stockId))
    .filter(Boolean);

  const sheetPanel = el('div', { className: 'bottom-sheet-panel' }, [
    el('div', { className: 'bottom-sheet-handle' }),
    el('div', { className: 'bottom-sheet-header' }, [
      el('h2', { id: 'bottom-sheet-title' }, etf.name + ' (' + etf.code + ')'),
      el(
        'button',
        {
          type: 'button',
          className: 'bottom-sheet-close',
          'data-testid': 'bottom-sheet-close',
          'aria-label': '바텀시트 닫기',
          onClick: ctx.onClose,
        },
        '닫기'
      ),
    ]),
    el('div', { className: 'bottom-sheet-price' }, [
      el('span', { className: 'etf-price' }, formatPrice(etf.currentPrice)),
      changeSpan(etf.changeRate1d),
    ]),
    el('div', { className: 'bottom-sheet-grid' }, [
      infoTile('순자산', formatKrw(etf.netAssets)),
      infoTile('거래대금', formatKrw(etf.tradingValue)),
      infoTile('총보수', typeof etf.totalFee === 'number' ? etf.totalFee.toFixed(2) + '%' : '정보 없음'),
      infoTile('테마', theme ? theme.name : '정보 없음'),
    ]),
    topStocks.length
      ? el('div', { className: 'bottom-sheet-holdings' }, [
          el('h3', {}, '주요 구성종목'),
          el(
            'p',
            {},
            topStocks.map((s) => s.name).join(', ')
          ),
        ])
      : null,
    el('div', { className: 'bottom-sheet-summary' }, [
      el('h3', {}, '상품 특성 요약'),
      el('p', {}, etf.summary),
    ]),
    el(
      'button',
      { type: 'button', className: 'bottom-sheet-detail-link' },
      '상세 정보 (샘플)'
    ),
  ]);

  container.appendChild(sheetPanel);
}

function infoTile(label, value) {
  return el('div', { className: 'info-tile' }, [
    el('span', { className: 'info-label' }, label),
    el('span', { className: 'info-value' }, value),
  ]);
}

export function setActiveButton(buttons, activeId, attr) {
  buttons.forEach((btn) => {
    const isActive = btn.dataset.value === activeId;
    btn.setAttribute(attr, String(isActive));
    btn.classList.toggle('active', isActive);
  });
}
